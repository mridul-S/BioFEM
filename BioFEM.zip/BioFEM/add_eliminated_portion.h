#include"declearation.h"


float add_eliminated_portion()
{

{printf("ELIMINATED PORTION\n");
   for(i=no2;i<(n-no2);i++)
    {//printf("checking");
         sum=0;
        for(j=0;j<no2;j++)
        {//printf("checking");
           sum=sum+(em1[i][j]*37);
           //printf("sum=%.2f\n",sum);

        }
        ns[i]=sum;

       // printf("\nns[%d]=%.2f\n",i,ns[i]);
    }
}



}
