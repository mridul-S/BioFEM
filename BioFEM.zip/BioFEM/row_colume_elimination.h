#include "declearation.h"

float row_column_elimination()
{
    for(i=0;i<n;i++)
{
    for(j=0;j<n;j++)
    {
       {
    em1[i][j]=em1[i+no2][j+no2];
       }

    }
}
}
