#include "declearation.h"

float right_side_vector_elimination()
{
  for(i=0; i<n; i++)
        {
                fm[i]=fm[i+no2];
        }

}
